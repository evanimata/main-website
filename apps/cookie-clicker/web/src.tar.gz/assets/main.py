"""Cookie Clicker game."""
import asyncio
import pygame as pg

class Game:
    def __init__(self) -> None:
        """Game object."""
        pg.init()
        self.screen_width = 800
        self.screen_height = 600
        self.screen = pg.display.set_mode((self.screen_width, self.screen_height))

        # Colors.
        self.black = (0, 0, 0)
        self.white = (255, 255, 255)

        # Objects.
        self.clock = pg.time.Clock()
        self.cookie = Cookie(self, self.screen_width/2, self.screen_height/2)
        self.font = pg.font.SysFont("Arial", 30)

        # Variables.
        self.fps = 60
        self.score = 0
        self.mouse_down = False

        # Sprite groups.
        self.sprites = pg.sprite.Group()
        self.sprites.add(self.cookie)

    async def main(self) -> None:
        """Main game loop."""
        running = True
        while running:
            self.clock.tick(self.fps)
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    running = False
                
                if event.type == pg.MOUSEBUTTONDOWN and not self.mouse_down:
                    self.mouse_down = True
                    self.score += 1
                    self.cookie.image = self.cookie.smaller_image
                    self.cookie.x = self.cookie.original_x - self.cookie.image.get_width()/2
                    self.cookie.y = self.cookie.original_y - self.cookie.image.get_height()/2
                    self.cookie.rect.x = self.cookie.x
                    self.cookie.rect.y = self.cookie.y

                if event.type == pg.MOUSEBUTTONUP and self.mouse_down:
                    self.mouse_down = False
                    self.cookie.image = self.cookie.main_image
                    self.cookie.x = self.cookie.original_x - self.cookie.image.get_width()/2
                    self.cookie.y = self.cookie.original_y - self.cookie.image.get_height()/2
                    self.cookie.rect.x = self.cookie.x
                    self.cookie.rect.y = self.cookie.y

            # Key presses.
            keys = pg.key.get_pressed()

            if keys[pg.K_ESCAPE]:
                running = False

            # Game updates.
            self.sprites.update()

            # Screen updates.
            self.screen.fill(self.white)
            self.sprites.draw(self.screen)
            self.score_text = self.font.render(f"Score: {self.score}", False, self.black)
            self.screen.blit(self.score_text, (10, 10))

            pg.display.update()
            await asyncio.sleep(0)


class Cookie(pg.sprite.Sprite):
    def __init__(self, game: Game, x: float, y: float) -> None:
        super().__init__()
        self.game = game
        self.image = pg.image.load("img/cookie.png")
        width, height = self.image.get_size()
        factor = 0.3 * self.game.screen_width / width
        smaller_factor = 0.28 * self.game.screen_width / width

        self.image = pg.transform.scale(self.image, (width*factor, height*factor))
        self.main_image = self.image
        self.smaller_image = pg.transform.scale(self.image, (width*smaller_factor, height*smaller_factor))

        self.rect = self.image.get_rect()

        self.angle = 0
        self.original_x = x
        self.original_y = y
        self.x = x - self.image.get_width()/2
        self.y = y - self.image.get_height()/2

        self.rect.x = self.x
        self.rect.y = self.y

    def update(self) -> None:
        """Main update method."""



if __name__ == "__main__":
    game = Game()
    try:
        asyncio.run(game.main())
    except KeyboardInterrupt:
        pass
