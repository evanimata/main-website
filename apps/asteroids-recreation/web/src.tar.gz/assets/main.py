"""Main Asteroids game."""
import asyncio
import numpy as np
import pygame as pg
import random

from pathlib import Path
from utils import velocity


root_dir = Path(__file__).resolve().parent


class Group(pg.sprite.Group):
    def __init__(self) -> None:
        """Initialize and inherit sprite group."""
        super().__init__()


class GameState:
    def __init__(self) -> None:
        """Initialize game."""
        pg.init()
        pg.font.init()
        self.screen_width = 800
        self.screen_height = 500
        self.screen = pg.display.set_mode((self.screen_width, self.screen_height))
        pg.display.set_caption("Asteroids!")

        # Colors.
        self.black = (0, 0, 0)

        # Objects.
        self.sprites = Group()
        self.spaceship = Spaceship(self, self.screen_width/2, self.screen_height - self.screen_height * 0.0625)
        # Initalize asteroids.
        min_init_asteroids = 3
        max_init_asteroids = 5
        self.asteroids_lst = [Asteroid(self, random.uniform(0, self.screen_width), random.uniform(0, self.screen_height * (3/4))) for i in range(random.randint(min_init_asteroids, max_init_asteroids))]
        self.sprites.add([
            self.spaceship,
        ] + self.asteroids_lst)
        self.lasers = Group()
        self.asteroids = Group()
        self.asteroids.add(self.asteroids_lst)

        # Game events and variables.
        self.player_lives = 3
        self.font = pg.font.SysFont("Arial", size=20)
        self.player_firing = False
        self.firing_cooldown = 0
        self.firing_cooldown_reset = 2
        self.asteroid_spawn_reset = 300
        self.asteroid_spawn = self.asteroid_spawn_reset
        self.player_score = 0
        self.clock = pg.time.Clock()

    async def play(self) -> None:
        """Main game loop."""

        running = True
        # Main game loop.
        while running:
            self.clock.tick(60)  # 60 FPS.

            # Reset conditions.
            self.player_firing = False
            self.firing_cooldown -= 1
            self.asteroid_spawn -= 1

            # Game events.
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    running = False

            if self.asteroid_spawn <= 0:
                self.asteroid_spawn = self.asteroid_spawn_reset
                self.make_asteroid()

            ship_asteroid_collisions = pg.sprite.spritecollide(self.spaceship, self.asteroids, dokill=False)
            if ship_asteroid_collisions:
                potential_asteroid = ship_asteroid_collisions[0]
                if isinstance(potential_asteroid, Asteroid):
                    potential_asteroid.get_hit(self.spaceship)

                self.player_lives -= 1
                if self.player_lives > 0:
                    self.spaceship.reset()
                else:
                    running = False
                    continue

            # Key pressing.
            keys = pg.key.get_pressed()
            if keys[pg.K_f] and self.firing_cooldown <= 0:
                laser = Laser(
                    self,
                    self.spaceship,
                    self.spaceship.x,
                    self.spaceship.y,
                )
                self.sprites.add(laser)
                self.lasers.add(laser)
                self.firing_cooldown = self.firing_cooldown_reset
            if keys[pg.K_SPACE]:
                self.player_firing = True
                self.spaceship.propel()
            if keys[pg.K_RIGHT]:
                self.spaceship.rotate(clockwise=True)
            if keys[pg.K_LEFT]:
                self.spaceship.rotate(clockwise=False)
            if keys[pg.K_ESCAPE]:
                running = False
                continue

            self.sprites.update()

            self.screen.fill(self.black)
            self.sprites.draw(self.screen)
            lives_display = self.font.render(f"Lives: {self.player_lives}", False, "white")
            self.screen.blit(lives_display, (10, 10))
            score_display = self.font.render(f"Score: {self.player_score}", False, "white")
            self.screen.blit(score_display, (self.screen_width-100, 10))
            pg.display.update()
            await asyncio.sleep(0)

        pg.quit()

    def make_asteroid(self) -> None:
        """Make new asteroid object and append it to all relevant Groups."""
        asteroid = Asteroid(self, random.uniform(0, self.screen_width), random.uniform(0, self.screen_height * (3/4)))
        self.sprites.add(asteroid)
        self.asteroids.add(asteroid)


class Sprite(pg.sprite.Sprite):
    def __init__(self, game: GameState, x: float, y: float) -> None:
        """Initialize and inherit."""
        super().__init__()
        self.x = x
        self.y = y
        self.game = game

    def scale(self, image: pg.Surface, factor: float) -> pg.Surface:
        """Scale down an image by a given factor."""
        width = image.get_width()
        height = image.get_height()
        return pg.transform.scale(image, (width * factor, height * factor))
    
    def get_rect(self) -> None:
        self.rect = self.image.get_rect(center=self.rect.center)
        self.rect.x = self.x - self.rect.width//2
        self.rect.y = self.y - self.rect.height//2


class Spaceship(Sprite):
    def __init__(self, game: GameState, x: float, y: float) -> None:
        """Initialize and inherit."""
        super().__init__(game, x, y)
        self.original_x = x
        self.original_y = y
        self.x_speed = 0
        self.y_speed = 0
        self.angle = 0
        self.speed = 0.5
        self.rotation_speed = 2.5

        scaling = 0.5
        self.default_sprite = self.scale(pg.image.load(root_dir / "sprites/spaceship.png"), scaling)
        self.firing_sprite = self.scale(pg.image.load(root_dir / "sprites/spaceship-firing.png"), scaling)
        self.image = self.default_sprite
        self.rect = self.image.get_rect()

        self.get_rect()

    def propel(self) -> None:
        """Add velocity to the spacecraft when spacekey pressed."""
        self.x_speed += velocity(self.speed, self.angle+90, "x") * 0.05
        self.y_speed += velocity(self.speed, self.angle-90, "y") * 0.05

    def rotate(self, clockwise: bool=True) -> None:
        """Rotate the ship on key press."""
        if clockwise:
            self.angle -= self.rotation_speed
        else:
            self.angle += self.rotation_speed
        self.image = pg.transform.rotate(self.image, self.angle)
        self.rect = self.image.get_rect(center=self.rect.center)

    def reset(self) -> None:
        """Reset the ship's coordinates when losing a life."""
        self.x = self.original_x
        self.y = self.original_y
        self.x_speed = 0
        self.y_speed = 0
        self.get_rect()

    def update(self) -> None:
        """Update method."""
        if self.x < 0:
            self.x = self.game.screen_width
        elif self.x > self.game.screen_width:
            self.x = 0
        if self.y < 0:
            self.y = self.game.screen_height
        elif self.y > self.game.screen_height:
            self.y = 0

        if self.game.player_firing:
            self.image = pg.transform.rotate(self.firing_sprite, self.angle)
        else:
            self.image = pg.transform.rotate(self.default_sprite, self.angle)

        self.x += self.x_speed
        self.y += self.y_speed

        self.get_rect()


class Laser(Sprite):
    def __init__(self, game: GameState, parent_ship: Spaceship, x: float, y: float) -> None:
        """Initialize and inherit."""
        super().__init__(game, x, y)
        self.parent_ship = parent_ship
        self.speed = 2
        self.x_speed = velocity(self.speed, self.parent_ship.angle+90, "x")
        self.y_speed = velocity(self.speed, self.parent_ship.angle-90, "y")
        self.image = self.scale(pg.image.load(root_dir / "sprites/laser.png"), 0.05)
        self.rect = self.image.get_rect()

        self.get_rect()

    def update(self) -> None:
        """Move laser and delete if colliding or offscreen."""
        self.x += self.x_speed
        self.y += self.y_speed

        self.get_rect()

        if self.x > self.game.screen_width or self.x < 0 or self.y > self.game.screen_height or self.y < 0:
            self.game.sprites.remove(self)
            del self


class Asteroid(Sprite):
    def __init__(self,
                 game: GameState,
                 x: float,
                 y: float,
                 scale_factor: float=0.75,
                 x_speed: float=None,
                 y_speed: float=None,
                 ) -> None:
        """Asteroid class."""
        super().__init__(game, x, y)
        self.num_children = 2
        self.grace_period = 3000 # Child asteroids might spawn on top of each other. Grace period so they can move away from each other.

        if not x_speed:
            self.x_speed = random.uniform(-1, 1)
            self.y_speed = random.uniform(-1, 1)
        else:
            self.x_speed = x_speed
            self.y_speed = y_speed
        self.scale_factor = scale_factor
        self.min_scale_factor_size = 0.4

        self.image = self.scale(pg.image.load(root_dir / "sprites/asteroid.png"), scale_factor)
        self.rect = self.image.get_rect()

        self.get_rect()

    def get_hit(self, collision_obj: Sprite=None) -> None:
        """Split the asteroid in half upon collision, or delete."""
        velocity_spread_percentages = np.linspace(0.90, 1.10, self.num_children)
        if self.scale_factor > self.min_scale_factor_size:
            if collision_obj:
                collision_force = 0.3
                x_speeds = np.array([self.x_speed + (collision_obj.x_speed * collision_force)] * self.num_children)
                y_speeds = np.array([self.y_speed + (collision_obj.y_speed * collision_force)] * self.num_children)
                if min(x_speeds) > min(y_speeds):
                    x_speeds *= velocity_spread_percentages
                else:
                    y_speeds *= velocity_spread_percentages
            else:
                x_speeds = [None] * self.num_children
                y_speeds = [None] * self.num_children

            children_asteroids = [Asteroid(self.game, self.x, self.y, self.scale_factor/2, x_speeds[asteroid], y_speeds[asteroid]) for asteroid in range(2)]

            self.game.asteroids.add(children_asteroids)
            self.game.sprites.add(children_asteroids)
        self.remove(self.game.asteroids, self.game.sprites)
        del self

    def update(self) -> None:
        """Move the asteroid."""
        # Check laser collision.
        laser_collisions = pg.sprite.spritecollide(self, self.game.lasers, dokill=True)
        if laser_collisions:
            laser = laser_collisions[0]
            self.get_hit(laser)
            self.game.player_score += 1
            return
    
        # Check asteroid collision.
        self.grace_period = self.grace_period - 1 if self.grace_period > 0 else self.grace_period
        asteroid_collisions = pg.sprite.spritecollide(self, self.game.asteroids, dokill=False)
        if len(asteroid_collisions) >= 2 and self.grace_period == 0:
            asteroid = asteroid_collisions[0]
            self.get_hit(asteroid)
            return

        if self.x < 0:
            self.x = self.game.screen_width
        elif self.x > self.game.screen_width:
            self.x = 0
        if self.y < 0:
            self.y = self.game.screen_height
        elif self.y > self.game.screen_height:
            self.y = 0

        self.x += self.x_speed
        self.y += self.y_speed
        self.get_rect()


if __name__ == "__main__":
    game = GameState()
    try:
        asyncio.run(game.play())
    except KeyboardInterrupt:
        pass
