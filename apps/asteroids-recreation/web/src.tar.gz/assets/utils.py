"""Math calculations and other utility functions."""
import math

def velocity(speed, angle, coordinate):
    # convert negative angles to positive
    if angle < 0:
        angle = 360 + angle
    # convert angle from degrees to radians
    angle *= (math.pi / 180)
    # return either the x or the y velocity
    if coordinate == 'x':
        return speed * math.cos(angle)
    if coordinate == 'y':
        return speed * math.sin(angle)
    